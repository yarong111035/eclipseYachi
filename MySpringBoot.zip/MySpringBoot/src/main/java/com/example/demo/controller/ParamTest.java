package com.example.demo.controller;

import java.util.Arrays;

import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.bean.User;
import com.example.demo.bean.UserList;
import com.example.demo.bean.UserMap;

@Controller
public class ParamTest {

	// 請求參數的應用
	@RequestMapping("/packge")
	@ResponseBody
	public String packge(@RequestParam(required = false,
			defaultValue = "99") Integer id) {
		
		System.out.println(id);	
		return id+"";
	}
	
	// 佔位符的應用
	@RequestMapping("/testRest/{id}/{name}")
	@ResponseBody
	public String testRest(@PathVariable("id") Integer id,
						   @PathVariable("name") String username ) {
		
		System.out.println(id);
		System.out.println(username);
		
		return id+" "+username;
	}
	
	
	// 請求參數傳陣列的應用
	@RequestMapping("/array")
	@ResponseBody
	public String array(@RequestParam(required = false)String[] name) {
			
		String str = Arrays.toString(name);		
		return str;
	}
	
	// 請求集合List封裝的應用
	@RequestMapping("/list")
	@ResponseBody
	public String list(UserList userList) {
		StringBuffer str = new StringBuffer();
		for ( User users : userList.getUsers()) {
			str.append(users.toString());
		}
		return str.toString();
	}
	@RequestMapping("/addList")
	public String addList() {
		return "addList";
	}
		
	
	//請求集合Map封裝的應用
	@RequestMapping("/map")
	@ResponseBody
	public String map(UserMap userMap) {
		StringBuffer str = new StringBuffer();
		for ( String key : userMap.getMasters().keySet()) {
			 User user = userMap.getMasters().get(key);
			str.append(user);
		}
		return str.toString();
	}
	@RequestMapping("/addMap")
	public String addMap() {
		return "addMap";
	}
	
	

}








