package com.example.demo.bean;

import java.util.Map;

import lombok.Data;

@Data
public class UserMap {
	private Map<String, User> masters;
}
