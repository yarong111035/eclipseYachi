package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.autoconfigure.AutoConfigurationPackage;
import org.springframework.boot.autoconfigure.AutoConfigurationPackages;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import com.example.demo.bean.User;
import com.example.demo.config.firstConfig;



//@SpringBootConfiguration  // @Configuration代表當前是一個配置類
//
//// 自動配置包 指定了默認的包規則
//// @Import(AutoConfigurationPackages.Registrar.class)
//// 利用Registrar給容器導入一系列的組件
//// 將指定的一個包下的所有組件導入進來  ---> MySpringBootApplication所在的包下 
//// 默認的包路徑 "com.example.demo"
//@EnableAutoConfiguration
//@ComponentScan()  // 指定掃描包 可指定或不指定

// 主程序類 主配置類
@SpringBootApplication  
public class MySpringBootApplication {

	public static void main(String[] args) {
		
		// 返回IOC容器
		ConfigurableApplicationContext run = SpringApplication
				.run(MySpringBootApplication.class, args);
		
		// 查看IOC容器裡面的組件
//		String[] names = run.getBeanDefinitionNames();
//		for (String name : names) {
//			System.out.println(name);
//		}
		
		// 從IOC容器中獲得(Bean)
//		Master master = run.getBean("master1",Master.class);
//		System.out.println(master);
//		
//		
//		// firstConfig配置類本身也是容器中的一個組件
//		// com.example.demo.config.firstConfig$$EnhancerBySpringCGLIB$$1d0fd573@50bf795f
//		firstConfig fbean = run.getBean(firstConfig.class);
//		System.out.println(fbean);
//		
//		// 如果@Configuration(proxyBeanMethods = true)代理對象調用方法
//		// Spring Boot 會檢查這個組件是否在容器中有
//		// 保持組件單實例
//		Master m1 = fbean.master1();
//		Master m2 = fbean.master1();
//		System.out.println(m1 == m2); //true
		
		System.out.println("--------------------------------------------"
				+ "運行成功-----------------------------------");

	}
	
}





