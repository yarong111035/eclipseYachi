package com.example.demo.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.websocket.Session;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.InternalResourceView;

import com.example.demo.bean.User;

@Controller
@RequestMapping("/model")
// @SessionAttributes(value = {"user"})
// 只要把user加到 request 對象裡
// @SessionAttributes會自動的加到session裡
public class ModelTest {			
	
	
	// Spring MVC 模型數據解析
	// JSP的四大作用域對應的內置對象  
	// pageContext / request / session / application
	// 提供了以下幾種方式添加模型數據 
	// Map / Model / ModelAndView / @SessionAttribute /@ModelAttribute
	// 這些都是將模型數據綁定到 request 對象裡
	
	// Model的模型數據應用
	@RequestMapping("/model")
	public String model(Model model) {
		User user = new User();
		user.setId(2);
		user.setName("小夫");
		model.addAttribute("user",user);
		
		return "index";
	}

	// Map的模型數據應用
	@RequestMapping("/map")
	public String map(Map<String, User> map) {
		User user = new User();
		user.setId(1);
		user.setName("胖虎");
		map.put("user", user);
		
		return "index";
	}
	
	//---------------------------------------------------------------------

	// @ModelAttribute的模型數據應用 
	// 需要定義一個方法 該方法專門用來返回要填充到模型數據中的對象
	// 該方法會優先填充到模型中
	// 業務方法中無須再處理模型 
	// 只要返回視圖邏輯即可
	
	@ModelAttribute
	public User getUser() {
		User user = new User();
		user.setId(6);
		user.setName("多拉E夢");
		
		return user;  
	}
	
	// void的使用 
//	@ModelAttribute
//	public void getUser(Model model) {
//		User user = new User();
//		user.setId(7);
//		user.setName("多拉F夢");
//		model.addAttribute("user",user);
//	}	
	@RequestMapping("/modelAttribute")
	public String modelAttribute() {
		return "/index";
	}
	
	
	// HttpServletRequest的模型數據應用
	@RequestMapping("/request")
	public String request(HttpServletRequest request) {
		User user = new User();
		user.setId(6);
		user.setName("多拉D夢");
		request.setAttribute("user", user);
		
		return "/index";
	}
	
	//---------------------------------------------------------------------
	
	// Session的應用 使用原生的Servlet API
	@RequestMapping("/session")
	public String Session(HttpSession session) {
		User user = new User();
		user.setId(7);
		user.setName("多拉D夢");
		session.setAttribute("user", user);
		
		return "/index";
	}
		
	// Session的應用  使用原生的Servlet API
	@RequestMapping("/session2")
	public String Session2(HttpServletRequest request) {
		HttpSession session = request.getSession();
		User user = new User();
		user.setId(7);
		user.setName("多拉D夢");
		session.setAttribute("user", user);
		
		return "/index";
	}
	
	//---------------------------------------------------------------------

	
	
	// ModelAndView的模型數據應用
	@RequestMapping("/modelAndView")
	public ModelAndView modelAndView() {
		User user = new User();
		user.setId(3);
		user.setName("大雄");
		ModelAndView view = new ModelAndView();
		view.addObject("user",user);
		view.setViewName("index");
		
		return view;
	}
	
	@RequestMapping("/modelAndView2")
	public ModelAndView modelAndView2() {
		User user = new User();
		user.setId(4);
		user.setName("多拉A夢");
		ModelAndView view = new ModelAndView();
		view.addObject("user",user);

		InternalResourceView internalResourceView = 
				new InternalResourceView("/index");
		view.setView(internalResourceView);
		return view;
	}
	
	@RequestMapping("/modelAndView3")
	public ModelAndView modelAndView3() {
		User user = new User();
		user.setId(5);
		user.setName("多拉B夢");
		ModelAndView view = 
				new ModelAndView("/index");
		view.addObject("user",user);

		return view;
	}
	
	@RequestMapping("/modelAndView4")
	public ModelAndView modelAndView4() {
		User user = new User();
		user.setId(6);
		user.setName("多拉C夢");
		Map<String, User> map = new HashMap<>();
		map.put("user", user);
		ModelAndView view = 
				new ModelAndView("/index",map);
	
		return view;
	}
	
	@RequestMapping("/modelAndView5")
	public ModelAndView modelAndView5() {
		User user = new User();
		user.setId(6);
		user.setName("多拉D夢");
		ModelAndView view = 
				new ModelAndView("/index","user",user);

		return view;
	}
	
	
	// application的模型數據應用
	@RequestMapping("/application")
	public String application(HttpServletRequest request) {
		ServletContext application = request.getServletContext();
		User user = new User();
		user.setId(8);
		user.setName("多拉D夢");
		application.setAttribute("user", user);
		
		return "/index";
	}
}









