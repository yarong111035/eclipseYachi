package com.example.demo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.example.demo.bean.User;
import com.example.demo.bean.Pet;

/*
 *  1. 配置類裡面使用@Bean註釋 在方法上用於給容器註冊組件(Bean) 默認是單實例(singleton)
 *  2. firstConfig配置類本身也是容器中的一個組件
 *  3. proxyBeanMethods = true  代理Bean的方法 true表示保持組件單實例
 *     外部無論對配置類中的這個組件註冊方法調用多少次 獲取的都是之前註冊容器中的單實例對象
 *     解決組件依賴
 *     Full(proxyBeanMethods = true)  有依賴關係 會檢查
 *     Lite(proxyBeanMethods = false) 無依賴關係 不會檢查 運行速度比較快
 */

// @Configuration 告訴Spring Boot這是一個配置類 == 以前的配置文件XML
@Configuration(proxyBeanMethods = false)
public class firstConfig {   
	
	@Bean  
	// @Bean 等同於<Bean>標籤   
	// 給IOC容器中添加組件 以方法名(m1)作為組件的Id 
	// 返回值類型(Master)就是組件類型 <Bean>標籤的class 
	// 返回的值就是組件在容器中的實例
	public User master1() {
		return new User("大雄", 18);
	}
	
	// Full(proxyBeanMethods = true) 用法如下
//	public Master master2() {
//		Master m2 = new Master("小夫", 18);
//		
//		// master組件依賴了pet組件
//		m2.setPet(pet1());
//		return new Master("大雄", 18);
//	}
	
	
	@Bean("petAAA")
	public Pet pet1() {
		return new Pet("黑熊");
	}
	
	
}
