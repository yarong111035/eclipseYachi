package com.example.demo.bean;

import java.util.List;

import lombok.Data;

@Data
public class UserList {
	
	private List<User> users;
}
