package com.example.demo.controller;

import java.util.Date;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

// @RestController註解相當於@ResponseBody ＋ @Controller合在一起的作用。
// 表示當下的java是一個控制器(Controller)。
@Controller  
public class HelloController {

	/*
	 * @RequestMapping 注解就是通過它來處理URL的請求，
	 * 而這個動作相等於 Servlet中在web.xml的配置
	 * 這個表示當URL的請求是”/hello” 就會執行 @RequestMapping("/hello")
	 * 當你在客戶端的瀏覽器輸一個網址時就會觸發。
	 * 假設你輸入了http://localhost:8080/
     * 系統就會先在去有@RestController注解的.java (即 Controller) 
     * 去查找有沒有一個@RequestMapping("/")的設定。
     * 如果是有的話，就要運行它下面的程式，否則就會報錯
	 * 
	 **/
	@RequestMapping({"","/index"}) 
	public String jspHome(Model model) {
		
		model.addAttribute("welcome","這是JSP的頁面");
		model.addAttribute("today",new Date());
		
		return "index";  //視圖指定向index.jsp
	}

	
}
