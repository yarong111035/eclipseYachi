package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.example.demo.entity.Member;
import com.example.demo.service.MemberServiceImpl;

@Controller
@SessionAttributes(types = Member.class)
public class HelloController {
	
	@Autowired
	MemberServiceImpl memberServiceImpl;
	
	// 首頁的映射
	@RequestMapping({"/","/index"}) 
	public String jspHome(Model model) {
		
		return "index";  //視圖指定向index.jsp
	}
	
	
	@RequestMapping("/_00_util/allUtil/jsp/header") 
	public String header_fragment(Model model) {
		
		String name = SecurityContextHolder.getContext()
				.getAuthentication().getName();
		Member member = memberServiceImpl.findUsername(name);
		
		model.addAttribute("member",member);
		
		return "/_00_util/allUtil/jsp/header"; 
	}
	
	
	
}
