package com.example.demo.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.example.demo.service.MemberServiceImpl;

@RestController
public class AdminController {

	@Autowired
	MemberServiceImpl memberServiceImpl;
	
	@RequestMapping("/admin")
	public String admin() {
		
		return "這裡是管理員的頁面，只有管理員才能訪問";
		
	}
	
	
	@RequestMapping(value = "/test",params = {"username","age != 12"})
	public String test() {
		return "測試成功";
	}
	
	
}
