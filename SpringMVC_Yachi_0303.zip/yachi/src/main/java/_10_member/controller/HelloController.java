package _10_member.controller;



import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HelloController {
	
	
	// 首頁的映射
	@RequestMapping({"/","/index"}) 
	public String jspHome(Model model) {
		
		return "/_11_member/index";  //視圖指定向index.jsp
	}
	
	
	
	
}
